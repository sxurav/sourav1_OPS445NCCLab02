#!/usr/bin/env python3

name = 'Jon'
age = 20
print('Hi ' + name + ', you are ' + str(age) + ' years old.')
