#!/usr/bin/env python3

name = 'Jon'
age = 20
colour = input("Type in a colour and press enter: ")
print('The colour I typed in is: ' + colour)
