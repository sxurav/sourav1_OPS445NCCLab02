#!/usr/bin/env python3

name = input("Name: ")
age = input("Age: ")
print('Hi ' + name + ', you are ' + str(age) + ' years old.')
