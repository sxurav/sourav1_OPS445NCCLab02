#!/usr/bin/env python3

# Author: Sourav
# Author ID: 156533226
# Date Created: [2025/02/07]

timer = 10

while timer > 0:
    print(timer)
    timer -= 1

print("blast off!")
